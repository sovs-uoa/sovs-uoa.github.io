# Jumping fish 

This application will display jumping fish in a web-browser

You should be able to link to a demonstration [here](https://sovs-uoa.github.io/fish/index.html)


