# eFish fpr Penguins 

This application will display stimulus in a web-browser

You should be able to link to a demonstration [here](https://sovs-uoa.github.io/fish/preferential.html)





