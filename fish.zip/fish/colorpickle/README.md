## Colorpickle
[Colorpickle](https://www.fakiirimedia.com/colorpickle) is a color picker plugin for jQuery. Colorpickle offers plenty of options and custom looks via theming.

## Documentation
Colorpickle documentation and examples can be found at [Colorpickle homepage](https://www.fakiirimedia.com/colorpickle).